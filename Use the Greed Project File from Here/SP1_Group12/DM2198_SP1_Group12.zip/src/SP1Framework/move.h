#ifndef _MOVE_H
#define _MOVE_H

#include "game.h"
#include "directions.h"
#include "hinting.h"

bool move(Player& P, Directions D);//Player Movement

#endif // _MOVE_H