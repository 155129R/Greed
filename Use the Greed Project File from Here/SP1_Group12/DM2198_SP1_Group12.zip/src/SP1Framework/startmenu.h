#ifndef _STARTMENU_H
#define _STARTMENU_H


void renderMenu();//Render Menu Screen
void selectMenuInput();//Process start menu inputs


#endif