#ifndef _COUNTDOWNTIMER_H
#define _COUNTDOWNTIMER_H

#include "game.h"

extern bool hasStarted;//Whether the game has started or not

void countdownUpdate(double T, Player& P);//Done by Glence,check whether timer ends ends 

#endif