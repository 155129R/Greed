#ifndef gameGUI
#define gameGUI
#include "game.h"

void drawPlayerGUI(COORD loc, unsigned int P);//render user interface

#endif