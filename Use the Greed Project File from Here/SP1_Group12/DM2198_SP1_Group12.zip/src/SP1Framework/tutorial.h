#ifndef _TUTORIAL_H
#define _TUTORIAL_H

#include "Framework\console.h"


extern Console g_Console;
void renderTutorial();//Render Tutorial



#endif  