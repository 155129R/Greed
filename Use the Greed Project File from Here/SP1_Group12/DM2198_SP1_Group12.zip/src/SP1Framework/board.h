#ifndef _BOARD_H
#define _BOARD_H
#include "game.h"

void boardGen();//Description of function. Summarise
void renderMap();//Prints board.
void renderCharacter();//Generate Board

extern unsigned char playerChar;

#endif