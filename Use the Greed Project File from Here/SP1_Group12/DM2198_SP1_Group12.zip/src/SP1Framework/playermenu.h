#include <iostream>

void applyplayer();// set 1 player of 2 player for game
void totalplayerNumber();//find total amount of players

enum numberofPlayers//enum for amount of players
{

   Single =1,
   Multi = 2

};
