#ifndef _TEST_H
#define _TEST_H

struct PSize//For board
{
	size_t X;
	size_t Y;
};


extern PSize fieldSize;



#endif // _TEST_H