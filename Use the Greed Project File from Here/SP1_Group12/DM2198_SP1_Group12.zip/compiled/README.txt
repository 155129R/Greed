   ___                        _     ___         _                   _            _ 
  / __|  _ _   ___   ___   __| |   | _ \  ___  | |  ___   __ _   __| |  ___   __| |
 | (_ | | '_| / -_) / -_) / _` |   |   / / -_) | | / _ \ / _` | / _` | / -_) / _` |
  \___| |_|   \___| \___| \__,_|   |_|_\ \___| |_| \___/ \__,_| \__,_| \___| \__,_|

To run the game, just double-click on the .exe file to get started! Enjoy!
  ___         _           _    
 / __|___ _ _| |_ _ _ ___| |___
| (__/ _ \ ' \  _| '_/ _ \ (_-<
 \___\___/_||_\__|_| \___/_/__/

In Greed Reloaded,We have 2 control scheme for the players
Please select your controls before starting the game.

First:   Q W E    Q->Move diagonally up-left   W-> Move Up    E->Move diagonally up-right
	 A   D	  A->Move Left                                D->Move Right
	 Z X C	  Z->Move diagonally down-left X->Move Down   C->Move diagonally down-right

Second  1 2 3     1->Move diagonally up-left   2-> Move Up    3->Move diagonally up-right
	4   6	  4->Move Left                                6->Move Right
        7 8 9 	  7->Move diagonally down-left 8->Move Down   9->Move diagonally down-right

Standardised miscellaneous controls

R-Retry
ESC-Move back to previous screen(When in the menus)/End the game(During gameplay)



  ___  _     _        _   _         
 / _ \| |__ (_)___ __| |_(_)_ _____ 
| (_) | '_ \| / -_) _|  _| \ V / -_)
 \___/|_.__// \___\__|\__|_|\_/\___|
          |__/                      

For all game modes:

The objective of this game mode is to "eat" up points as much as possible by moving your character across the board.
The way the movement system works is that the number in the blocks surrounding 
your character will dictate how many blocks you will eat if you move towards that number.
Moving towards that direction will move your character in that direction,eating up the blocks
and gaining points.The game will end when the player no longer can make a move.


Normal Mode Single Player

The standard mode for Greed Reloaded.The game will end when the player cannot make a move.


Timed Mode Single Player

The player will be given a set amount of time.
During that time the player must try to gain as many points as possible before the time runs out.

The game will end when the timer runs out or the player can no longer make a move


Normal Mode Multiplayer

Similar to its singleplayer counterpart, Normal Mode multiplayer will require 2 players.
Each player will take turns to move their character.
The player that can no longer make a move loses the game.
The other player will be declared the winner.


Timed Mode Multiplayer

Timed Mode for Multiplayer works differently from the single player timed mode.
Each player will only have 10 secs to make a move or else they lose the game.
The game will end when a player can no longer make a move or when the player take longer than 10 secs to move

			